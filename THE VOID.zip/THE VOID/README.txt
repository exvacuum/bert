Mess around with the hex in the end of the file to change parts of the objects, or copy stuff to make your own!

Keys in order
1 - x
2 - y
3 - width
4 - height
5 - type
	(0 = Generic)
	(1 = Solid (Unfinished))
	(2 = Light Source)
	(3 = Player)